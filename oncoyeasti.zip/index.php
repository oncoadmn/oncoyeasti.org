<!DOCTYPE HTML>

<html>
<head>
	<title>Oncoyeasti</title>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
	<link rel="stylesheet" href="assets/css/main.css" />
	<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
</head>
<body>

	<!-- Banner -->
	<section id="banner">
		<div class="inner split">
			<section>
				<h2>Oncoyeasti </h2>
			</section>
			<section>
				<p >Human Homologs of Saccharomyces Cerevisiae Genes and the Status of the Corresponding Homologs in the Tumor Samples of TCGA Database and Cancer Cell Lines present in CCLE Database</p>
			</section>
		</div>
	</section>

	<!-- One -->
	<section id="one" class="wrapper">
		<div class="inner split">
			
			<section>
				<p>Enter Saccharomyces cerevisiae Gene names <br/>
					In standard gene name or systematic gene name format <br/>
					One name per line, 100 gene names max.</p>

				</section>
				<section>

					<form action="" class="alt" method="POST">
						<div class="row uniform">
							<div class="12u$">
								<textarea name="search" placeholder="Enter gene names, one per line" rows="4"></textarea>
							</div>
						</div>
						<ul class="actions">
							<li><input class="alt" value="Load" type="submit"></li>
						</ul>
					</form>

				</section>
			</div>
		</section>


		<section id='two' class='wrapper style2 alt'>
			<div class=''>
				<div class='spotlight'>
					
					<div class = 'content'>

						<?php
					
					$response = "Unable to search!!";
					if(isset($_POST['search']) && strlen($_POST['search'])>0)
					{
						$db_h = mysqli_connect("localhost","oncoyeas_grsgr13","Bappa12#");
						$db_f = mysqli_select_db($db_h, "oncoyeas_grsgr");
						$output = ' ';
						if($db_h && $db_f)
						{
							$searches = array_map('trim', explode("\n", $_POST['search']));

							$search_terms = array();
							foreach ($searches as $search) {
							    $search_terms[] = "'%".mysqli_real_escape_string($db_h, $search)."%'";
							}

							$Gene_Standard_Search = implode(' OR Gene_Standard LIKE ', $search_terms);
							$Gene_Systematic_Search = implode(' OR Gene_Systematic LIKE ', $search_terms);

							$query = mysqli_query($db_h, "SELECT * FROM text4 WHERE Gene_Standard LIKE $Gene_Standard_Search OR Gene_Systematic LIKE $Gene_Systematic_Search") or $response = "Access Denied!";
							if(mysqli_num_rows($query) > 0)
							{
								echo "
								<table class = 'bord'>
									<thead>
										<tr>
										<th>S/N</th>
										<th>S Cerevisiae  Standard Gene Name</th>
										<th>S Cerevisiae  Systematic Gene Name</th>
										<th>Homologous Homo Sapien Gene/Genes</th>
										<th>Cross Cancer Summary in Tumors present in TCGA Database</th>
										<th>CCLE Cancer Cell Lines Summary</th>
									</tr>
								</thead>
								<tbody>";
								$countre = 1;
								while($row = mysqli_fetch_array($query))
								{

								echo "
								<tr>
								<td> $countre </td> 
								<td>" . $row['Gene_Standard'] . "</td>
								<td>" . $row['Gene_Systematic'] . "</td>
								<td>" . $row['Homologue_Standard'] . "</td>
								<td><a href=\"{$row['URL']}\">Cross Cancer Summary</a></td>
								<td><a href=\"{$row['URLC']}\">CCLE Cell Lines Summary</a></td>
								</tr>";
								$countre++;
								}
								echo"
								</tbody>
								</table>";

							}
							else
							{
								$response = "No results found";
							}
						}
						else
						{
							$response = "Access Denied!";
						}
						//collect




						
						
					}

					echo "<div class='row uniform'>

						
						<div class='12u$'>
							$response
						</div>


					</div>"; 
					

					?>

					

				</div>

				
			</div>
		</div>
	</section>

	<!-- Footer -->
	<footer id="footer">
		<div class="copyright">
			&copy; Oncoyeasti <?php echo date("Y"); ?>. All rights reserved. Designed by : <a href="https://chuksy.org" target = "_blank">Chuksy Labs</a>.
		</div>
	</footer>

	<!-- Scripts -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/skel.min.js"></script>
	<script src="assets/js/util.js"></script>
	<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
	<script src="assets/js/main.js"></script>

</body>
</html>