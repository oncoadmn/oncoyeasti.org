<!DOCTYPE HTML>

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
	<title>Oncoyeasti</title>
	
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
	<link rel="stylesheet" href="assets/css/main.css" />
	<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->
	

	
</head>
<body>

	<!-- Banner -->
	<section id="banner">
		<div class="inner split">
			<section>
				<h2>Oncoyeasti </h2>
			</section>
			<section>
				<p >Human Homologs of Saccharomyces Cerevisiae Genes and the Status of the Corresponding Homologs in the Tumor Samples of TCGA Database and Cancer Cell Lines present in CCLE Database</p>
			</section>
		</div>
	</section>

	<!-- One -->
	<section id="one" class="wrapper">
		<div class="inner split">
			
			<section>
				<p>Enter Saccharomyces cerevisiae Gene names <br/>
					In standard gene name or systematic gene name format <br/>
					One name per line, 100 gene names max.</p>

				</section>
				<section>

					<form action="" class="alt" method="POST">
						<div class="row uniform">
							<div class="12u$">
								<textarea name="search" placeholder="Enter gene names, one per line" rows="4"></textarea>
							</div>
						</div>
						<ul class="actions">
							<li><input class="alt" value="Load" type="submit"></li>
						</ul>
					</form>

				</section>
			</div>
		</section>


		<section id='two' class='wrapper style2 alt'>
			<div class=''>
				<div class='spotlight'>
					
					<div class = 'content'>

						<?php
					
					$response = "Search Results!!";
					$response = "";
					if(isset($_POST['search']) && strlen($_POST['search'])>0)
					{
						$db_h = mysqli_connect("localhost","oncoyeas_grsgr13","Bappa12#");
						$db_f = mysqli_select_db($db_h, "oncoyeas_grsgr");
						$output = ' ';
						if($db_h && $db_f)
						{
							$searches = array_map('trim', explode("\n", $_POST['search']));

							$search_terms = array();
							foreach ($searches as $search) {
							if(strlen(trim($search)) > 0){
							    //$search_terms[] = "'%".mysqli_real_escape_string($db_h, $search)."%'";
							    $search_terms[] = "'".mysqli_real_escape_string($db_h, $search)."'";
							    }
							}

							$Gene_Standard_Search = implode(' OR Gene_Standard LIKE ', $search_terms);
							$Gene_Systematic_Search = implode(' OR Gene_Systematic LIKE ', $search_terms);
							$Homologue_Standard_Search = implode(' OR Homologue_Standard LIKE ', $search_terms);

							$query = mysqli_query($db_h, "SELECT * FROM text216 WHERE Gene_Standard LIKE $Gene_Standard_Search  OR Homologue_Standard LIKE $Homologue_Standard_Search") or $response = "Access Denied!";
							if(mysqli_num_rows($query) > 0)
							{
								echo "
								<table class = 'bord'>
									<thead>
										<tr>

										<th>S/N</th>
										<th><i>S.Cerevisiae</i> STANDARD GENE NAME</th>
										<th><i>S.Cerevisiae</i> SYSTEMATIC GENE NAME</th>
										<th>HOMOLOG GENES IN <i>Homo Sapiens</i></th>
										
										<th>CCLE CANCER CELL LINES</th>
										<th><nobr>NCI 60</nobr> CELL LINES</th>
										<th><nobr>CROSS CANCER SUMMARY </nobr>IN TUMORS PRESENT IN TCGA DATABASE</th>

									
<th><nobr>THE NEXT COLUMNS CONTAINS ONCOPRINT </nobr>OF TUMOR GROUPS PRESENT IN CROSS <nobr>CANCER SUMMARY STUDIES OF THE </nobr>PATIENT TUMOR SETS PRESENT IN TCGA DATABASE</th>
<th><nobr>PanCancer Studies MSK IMPACT</nobr> Clinical Sequencing Cohort</i></th>
<th><nobr>Pan Lung </nobr>Cancer</i></th><th>Adrenocortical Carcinoma</th>
<th>Ampula of Vater</th>
<th>Biliary Tract Cholangiocarcinoma</th>
<th>Gall Bladder Cancer</th>
<th>Bladder Urothelial Carcinoma</th>
<th>Upper Tract Urothelial Carcinoma</th>
<th>Ewing Sarcoma</th>
<th>Colorectal Adenocarcinoma</th>
<th>Invasive Breast Carcinoma</th>
<th>Diffuse Glioma</th>
<th>Embryonal Tumor</th>
<th>Encapsulated Glioma</th>
<th>Misc Neuroepithelial Tumor</th>
<th>Cervical Squamous Cell Carcinoma</th>
<th>Esophageal Squamous Cell Carcinoma</th>
<th>Esophagogastric Adenocarcinoma</th>
<th>Esophageal Adenocarcinoma</th>
<th>Stomach Adenocarcinoma</th>
<th>Ocular Melanoma</th>
<th>Recurrent Metastatic Head Neck Cancer</th>
<th>Head Neck Squamous Cell Carcinoma</th>
<th>Nasopharyngeal Carcinoma</th>
<th>Salivary Carcinoma</th>
<th>Renal Clear Cell Carcinoma</th>
<th>Renal Non Clear Cell Carcinoma</th>
<th>Rhabdoid Cancer</th><th>Wilms Tumor</th>
<th>Hepatocelluar Adenoma</th>
<th>Hepatocellular Carcinoma</th>
<th>Lung Neuroendocrine Tumor Small Cell Lung Cancer</th>
<th>Non Small Cell Lung Cancer</th>
<th>Lung Adenocarcinoma</th>
<th>Lung Squamous Cell Carcinoma</th>
<th>B Lymphoblastic Leukemia Lymphoma</th>
<th>Mature B Cell Neoplasm</th>
<th>Mature T NK Neoplasm</th>
<th>Myeloid Neoplasm</th>
<th>Acute Myeloid Leukemia</th>
<th>Myelodyspastic Syndromes</th>
<th>Other Mixed Cancer Types</th>
<th>Ovary Fallopian Tube</th>
<th>Ovarian Epithelial Tumor Serous Ovarian Cancer</th>
<th>Ovarian Epithelial Tumor Small Cell Carcinoma of the Ovary</th>
<th>Pancreas Acinar Cell Carcinoma of the Pancreas</th>
<th>Cystic Tumor of the Pancreas</th>
<th>Pancreatic Adenocarcinoma</th>
<th>Pancreatic Neuroendocrine Tumor</th>
<th>Peripheral Nervous System Nerve Sheath Tumor</th>
<th>Neuroblastoma</th><th>Pleural Mesothelioma</th>
<th>Prostate Adenocarcinoma</th>
<th>Skin Cutaneous Squamous Cell Carcinoma</th>
<th>Melanoma</th>
<th>Cutaneous Melanoma</th>
<th>Desmoplastic Melanoma</th>
<th>Soft Tissue</th>
<th>Angiosarcoma</th>
<th>Rhabdomyosarcoma</th>
<th>Testis</th>
<th>Non Seminomatous Germ Cell Tumor</th>
<th>Thymic Epithelial Tumor</th>
<th>Thymoma</th>
<th>Thyroid</th>
<th>Well Differentiated Thyroid Cancer</th>
<th>Uterus Endometrial Carcinoma</th>
<th>Uterine Malignant Mixed Mullerian Tumor</th>	
								
									
								
		</tr>							
									</tr>
								</thead>
								<tbody>";
								$countre = 1;
								while($row = mysqli_fetch_array($query))
								{

								echo "
								<tr>
								<td> $countre </td> 
								<td>" . $row['Gene_Standard'] . "</td>
								<td>" . $row['Homologue_Standard1'] . "</td>
								<td>" . $row['Homologue_Standard'] . "</td>
								
								<td><a href=\"{$row['URLC']}\">CCLE Summary</a></td>

<td><a href=\"{$row['URLNCI_60_Cell_Lines']}\">NCI 60</a></td>
<td><a href=\"{$row['URL']}\">TCGA Summary</a></td>
<td>Next following columns</td>


<td><a href=\"{$row['URLPanCancer_Studies_MSK_IMPACT_Clinical_Sequencing_Cohort']}\">MSK IMPACT</a></td>
<td><a href=\"{$row['URLPan_Lung_Cancer']}\">Pan Lung Cancer</a></td>
<td><a href=\"{$row['URLAdrenocortical_Carcinoma']}\">Adrenocortical Carcinoma</a></td>
<td><a href=\"{$row['URLAmpula_of_Vater']}\">Ampula of Vater</a></td>
<td><a href=\"{$row['URLBiliary_Tract_Cholangiocarcinoma']}\">Biliary Tract Cholangiocarcinoma</a></td>
<td><a href=\"{$row['URLGall_Bladder_Cancer']}\">Gall_Bladder_Cancer</a></td>
<td><a href=\"{$row['URLBladder_Urothelial_Carcinoma']}\">Bladder_Urothelial_Carcinoma</a></td>
<td><a href=\"{$row['URLUpper_Tract_Urothelial_Carcinoma']}\">Upper_Tract_Urothelial_Carcinoma</a></td>
<td><a href=\"{$row['URLEwing_Sarcoma']}\">Ewing_Sarcoma</a></td>
<td><a href=\"{$row['URLColorectal_Adenocarcinoma']}\">Colorectal_Adenocarcinoma</a></td>
<td><a href=\"{$row['URLInvasive_Breast_Carcinoma']}\">Invasive_Breast_Carcinoma</a></td>
<td><a href=\"{$row['URLDiffuse_Glioma']}\">Diffuse_Glioma</a></td>
<td><a href=\"{$row['URLEmbryonal_Tumor']}\">Embryonal_Tumor</a></td>
<td><a href=\"{$row['URLEncapsulated_Glioma']}\">Encapsulated_Glioma</a></td>
<td><a href=\"{$row['URLMisc_Neuroepithelial_Tumor']}\">Misc_Neuroepithelial_Tumor</a></td>
<td><a href=\"{$row['URLCervical_Squamous_Cell_Carcinoma']}\">Cervical_Squamous_Cell_Carcinoma</a></td>
<td><a href=\"{$row['URLEsophageal_Squamous_Cell_Carcinoma']}\">Esophageal_Squamous_Cell_Carcinoma</a></td>
<td><a href=\"{$row['URLEsophagogastric_Adenocarcinoma']}\">Esophagogastric_Adenocarcinoma</a></td>
<td><a href=\"{$row['URLEsophageal_Adenocarcinoma']}\">Esophageal_Adenocarcinoma</a></td>
<td><a href=\"{$row['URLStomach_Adenocarcinoma']}\">Stomach_Adenocarcinoma</a></td>
<td><a href=\"{$row['URLOcular_Melanoma']}\">Ocular_Melanoma</a></td>
<td><a href=\"{$row['URLRecurrent_Metastatic_Head_Neck_Cancer']}\">Recurrent_Metastatic_Head_Neck_Cancer</a></td>
<td><a href=\"{$row['URLHead_Neck_Squamous_Cell_Carcinoma']}\">Head_Neck_Squamous_Cell_Carcinoma</a></td>
<td><a href=\"{$row['URLNasopharyngeal_Carcinoma']}\">Nasopharyngeal_Carcinoma</a></td>
<td><a href=\"{$row['URLSalivary_Carcinoma']}\">Salivary_Carcinoma</a></td>
<td><a href=\"{$row['URLRenal_Clear_Cell_Carcinoma']}\">Renal_Clear_Cell_Carcinoma</a></td>
<td><a href=\"{$row['URL']}\">Renal_Non_Clear_Cell_Carcinoma</a></td>
<td><a href=\"{$row['URLRhabdoid_Cancer']}\">Rhabdoid_Cancer</a></td>
<td><a href=\"{$row['URLWilms_Tumor']}\">Wilms_Tumor</a></td>
<td><a href=\"{$row['URLHepatocelluar_Adenoma']}\">Hepatocelluar_Adenoma</a></td>
<td><a href=\"{$row['URLHepatocellular_Carcinoma']}\">Hepatocellular_Carcinoma</a></td>
<td><a href=\"{$row['URLLung_Neuroendocrine_Tumor_Small_Cell_Lung_Cancer']}\">Lung_Neuroendocrine_Tumor_Small_Cell_Lung_Cancer</a></td>
<td><a href=\"{$row['URLNon_Small_Cell_Lung_Cancer']}\">Non_Small_Cell_Lung_Cancer</a></td>
<td><a href=\"{$row['URLLung_Adenocarcinoma']}\">Lung_Adenocarcinoma</a></td>
<td><a href=\"{$row['URLLung_Squamous_Cell_Carcinoma']}\">Lung_Squamous_Cell_Carcinoma</a></td>
<td><a href=\"{$row['URLB_Lymphoblastic_Leukemia_Lymphoma']}\">B_Lymphoblastic_Leukemia_Lymphoma</a></td>
<td><a href=\"{$row['URLMature_B_Cell_Neoplasm']}\">Mature_B_Cell_Neoplasm</a></td>
<td><a href=\"{$row['URLMature_T_NK_Neoplasm']}\">Mature_T_NK_Neoplasm</a></td>
<td><a href=\"{$row['URLMyeloid_Neoplasm']}\">Myeloid_Neoplasm</a></td>
<td><a href=\"{$row['URLAcute_Myeloid_Leukemia']}\">Acute_Myeloid_Leukemia</a></td>
<td><a href=\"{$row['URLMyelodyspastic_Syndromes']}\">Myelodyspastic_Syndromes</a></td>
<td><a href=\"{$row['URLOther_Mixed_Cancer_Types']}\">Other_Mixed_Cancer_Types</a></td>
<td><a href=\"{$row['URLOvary_Fallopian_Tube']}\">Ovary_Fallopian_Tube</a></td>
<td><a href=\"{$row['URLOvarian_Epithelial_Tumor_Serous_Ovarian_Cancer']}\">Ovarian_Epithelial_Tumor_Serous_Ovarian_Cancer</a></td>
<td><a href=\"{$row['URLOvarian_Epithelial_Tumor_Small_Cell_Carcinoma_of_the_Ovary']}\">Ovarian_Epithelial_Tumor_Small_Cell_Carcinoma_of_the_Ovary</a></td>
<td><a href=\"{$row['URLPancreas_Acinar_Cell_Carcinoma_of_the_Pancreas']}\">Pancreas_Acinar_Cell_Carcinoma_of_the_Pancreas</a></td>
<td><a href=\"{$row['URLCystic_Tumor_of_the_Pancreas']}\">Cystic_Tumor_of_the_Pancreas</a></td>
<td><a href=\"{$row['URLPancreatic_Adenocarcinoma']}\">Pancreatic_Adenocarcinoma</a></td>
<td><a href=\"{$row['URLPancreatic_Neuroendocrine_Tumor']}\">Pancreatic_Neuroendocrine_Tumor</a></td>
<td><a href=\"{$row['URLPeripheral_Nervous_System_Nerve_Sheath_Tumor']}\">Peripheral_Nervous_System_Nerve_Sheath_Tumor</a></td>
<td><a href=\"{$row['URLNeuroblastoma']}\">Neuroblastoma</a></td>
<td><a href=\"{$row['URLPleural_Mesothelioma']}\">Pleural_Mesothelioma</a></td>
<td><a href=\"{$row['URLProstate_Adenocarcinoma']}\">Prostate_Adenocarcinoma</a></td>
<td><a href=\"{$row['URLSkin_Cutaneous_Squamous_Cell_Carcinoma']}\">Skin_Cutaneous_Squamous_Cell_Carcinoma</a></td>
<td><a href=\"{$row['URLMelanoma']}\">Melanoma</a></td>
<td><a href=\"{$row['URLCutaneous_Melanoma']}\">Cutaneous_Melanoma</a></td>
<td><a href=\"{$row['URLDesmoplastic_Melanoma']}\">Desmoplastic_Melanoma</a></td>
<td><a href=\"{$row['URLSoft_Tissue']}\">Soft_Tissue</a></td>
<td><a href=\"{$row['URLAngiosarcoma']}\">Angiosarcoma</a></td>
<td><a href=\"{$row['URLRhabdomyosarcoma']}\">Rhabdomyosarcoma</a></td>
<td><a href=\"{$row['URLTestis']}\">Testis</a></td>
<td><a href=\"{$row['URLNon_Seminomatous_Germ_Cell_Tumor']}\">Non_Seminomatous_Germ_Cell_Tumor</a></td>
<td><a href=\"{$row['URLThymic_Epithelial_Tumor']}\">Thymic_Epithelial_Tumor</a></td>
<td><a href=\"{$row['URLThymoma']}\">Thymoma</a></td>
<td><a href=\"{$row['URLThyroid']}\">Thyroid</a></td>
<td><a href=\"{$row['URLWell_Differentiated_Thyroid_Cancer']}\">Well_Differentiated_Thyroid_Cancer</a></td>
<td><a href=\"{$row['URLUterus_Endometrial_Carcinoma']}\">Uterus_Endometrial_Carcinoma</a></td>
<td><a href=\"{$row['URLUterine_Malignant_Mixed_Mullerian_Tumor']}\">Uterine_Malignant_Mixed_Mullerian_Tumor</a></td>

								</tr>";
								$countre++;
								}
								echo"
								</tbody>
								</table>";

							}
							else
							{
								$response = "No results found";
							}
						}
						else
						{
							$response = "Access Denied!";
						}
						//collect




						
						
					}

					echo "<div class='row uniform'>

						
						<div class='12u$'>
							$response
						</div>


					</div>"; 
					

					?>

					

				</div>

				
			</div>
		</div>
	</section>

	<!-- Footer -->
	<footer id="footer">
		<div class="copyright">
			&copy; Oncoyeasti <?php echo date("Y"); ?>. All rights reserved.
		</div>
	</footer>

	<!-- Scripts -->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/skel.min.js"></script>
	<script src="assets/js/util.js"></script>
	<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
	<script src="assets/js/main.js"></script>

</body>
</html>